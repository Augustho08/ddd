'use client';

import { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import type { ImageRecord, ImagesPage } from '@/lib/types';
import { formatBytes, formatDate, formatResolution } from '@/lib/format';

const FORMATS = ['', 'jpeg', 'png', 'webp', 'heic'];

export default function AdminGallery() {
  const router = useRouter();
  const [items, setItems] = useState<ImageRecord[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(24);
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [format, setFormat] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Busca com atraso: evita uma requisição a cada tecla.
  useEffect(() => {
    const t = setTimeout(() => setQuery(search), 300);
    return () => clearTimeout(t);
  }, [search]);

  useEffect(() => {
    setPage(1);
  }, [query, format, from, to]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const params = new URLSearchParams({ page: String(page) });
    if (query) params.set('q', query);
    if (format) params.set('format', format);
    if (from) params.set('from', from);
    if (to) params.set('to', to);

    try {
      const res = await fetch(`/api/admin/images?${params.toString()}`, { cache: 'no-store' });
      if (res.status === 401) {
        router.replace('/admin/login');
        return;
      }
      const data = (await res.json()) as ImagesPage & { error?: string };
      if (!res.ok) {
        setError(data.error ?? 'Não foi possível carregar as imagens.');
        return;
      }
      setItems(data.items);
      setTotal(data.total);
      setLimit(data.limit);
    } catch {
      setError('Falha de conexão ao carregar as imagens.');
    } finally {
      setLoading(false);
    }
  }, [page, query, format, from, to, router]);

  useEffect(() => {
    void load();
  }, [load]);

  async function remove(item: ImageRecord) {
    const ok = window.confirm(`Excluir "${item.originalName}"? A imagem e os metadados serão removidos permanentemente.`);
    if (!ok) return;
    const res = await fetch(`/api/admin/images/${item.id}`, { method: 'DELETE' });
    if (res.ok) {
      setItems((prev) => prev.filter((i) => i.id !== item.id));
      setTotal((t) => Math.max(0, t - 1));
    } else {
      const data = await res.json().catch(() => ({}));
      window.alert(data.error ?? 'Não foi possível excluir a imagem.');
    }
  }

  async function logout() {
    await fetch('/api/admin/logout', { method: 'POST' });
    router.replace('/admin/login');
    router.refresh();
  }

  const pages = Math.max(1, Math.ceil(total / limit));

  return (
    <div className="space-y-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-xs text-accent">Área privada</p>
          <h1 className="mt-1 text-3xl font-bold tracking-tight text-white">Imagens recebidas</h1>
          <p className="mt-1 text-sm text-slate-400">{total} {total === 1 ? 'imagem' : 'imagens'} no total</p>
        </div>
        <button type="button" onClick={logout} className="btn-ghost">Sair</button>
      </header>

      <section className="panel grid gap-4 p-5 md:grid-cols-[2fr_1fr_1fr_1fr]" aria-label="Filtros">
        <label className="space-y-2 text-sm text-slate-400">
          Buscar
          <input className="input" placeholder="Nome, marca ou modelo" value={search} onChange={(e) => setSearch(e.target.value)} />
        </label>
        <label className="space-y-2 text-sm text-slate-400">
          Formato
          <select className="input" value={format} onChange={(e) => setFormat(e.target.value)}>
            {FORMATS.map((f) => (
              <option key={f || 'all'} value={f}>{f ? f.toUpperCase() : 'Todos'}</option>
            ))}
          </select>
        </label>
        <label className="space-y-2 text-sm text-slate-400">
          Enviada de
          <input className="input" type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </label>
        <label className="space-y-2 text-sm text-slate-400">
          Até
          <input className="input" type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </label>
      </section>

      {error && (
        <p role="alert" className="rounded-xl border border-red-900/60 bg-red-950/40 px-4 py-3 text-sm text-red-300">
          {error}
        </p>
      )}

      {loading && items.length === 0 && <p className="text-slate-500">Carregando…</p>}
      {!loading && !error && items.length === 0 && (
        <p className="panel p-8 text-center text-slate-400">Nenhuma imagem encontrada com esses filtros.</p>
      )}

      <section className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
        {items.map((item) => (
          <article key={item.id} className="panel flex flex-col overflow-hidden">
            <div className="relative aspect-[4/3] bg-ink">
              {item.hasThumbnail ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={`/api/admin/images/${item.id}/thumb`}
                  alt={`Miniatura de ${item.originalName}`}
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full items-center justify-center font-mono text-sm text-slate-500">
                  {item.format.toUpperCase()} sem miniatura
                </div>
              )}
              {item.latitude !== null && (
                <span className="absolute left-3 top-3 rounded-full bg-ink/80 px-2.5 py-1 font-mono text-xs text-glow">
                  GPS
                </span>
              )}
            </div>

            <div className="flex flex-1 flex-col gap-4 p-5">
              <div className="min-w-0">
                <h2 className="truncate font-semibold text-white" title={item.originalName}>{item.originalName}</h2>
                <p className="text-sm text-slate-400">Enviada em {formatDate(item.uploadedAt)}</p>
              </div>

              <dl className="grid grid-cols-2 gap-3 text-sm">
                <div><dt className="text-xs text-slate-500">Formato</dt><dd className="text-slate-200">{item.format.toUpperCase()}</dd></div>
                <div><dt className="text-xs text-slate-500">Tamanho</dt><dd className="text-slate-200">{formatBytes(item.sizeBytes)}</dd></div>
                <div className="col-span-2"><dt className="text-xs text-slate-500">Resolução</dt><dd className="text-slate-200">{formatResolution(item.width, item.height)}</dd></div>
                <div className="col-span-2"><dt className="text-xs text-slate-500">Dispositivo</dt><dd className="truncate text-slate-200">{[item.cameraMake, item.cameraModel].filter(Boolean).join(' ') || 'Não informado'}</dd></div>
              </dl>

              <details className="text-sm">
                <summary className="cursor-pointer text-accent">Ver metadados</summary>
                <pre className="mt-3 max-h-64 overflow-auto rounded-xl bg-ink p-3 font-mono text-xs text-slate-300">
                  {JSON.stringify(item.metadata, null, 2)}
                </pre>
              </details>

              <div className="mt-auto flex flex-wrap gap-2 pt-2">
                <a href={`/api/admin/images/${item.id}/download`} download className="btn-ghost flex-1">Baixar original</a>
                <button type="button" onClick={() => remove(item)} className="btn-danger flex-1">Excluir</button>
              </div>
            </div>
          </article>
        ))}
      </section>

      {total > limit && (
        <nav className="flex items-center justify-center gap-4" aria-label="Paginação">
          <button type="button" className="btn-ghost" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Anterior</button>
          <span className="text-sm text-slate-400">Página {page} de {pages}</span>
          <button type="button" className="btn-ghost" disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>Próxima</button>
        </nav>
      )}
    </div>
  );
}
