'use client';

import { useEffect, useMemo, useState, type FormEvent } from 'react';
import type { PhotoRecord } from '@/lib/types';
import { formatBytes, formatDate, formatResolution } from '@/lib/format';

function basicHeader(user: string, pass: string): string {
  const bytes = new TextEncoder().encode(`${user}:${pass}`);
  let binary = '';
  bytes.forEach((b) => {
    binary += String.fromCharCode(b);
  });
  return `Basic ${btoa(binary)}`;
}

/** Miniatura obtida pela API com autenticação (imagens não podem enviar cabeçalhos). */
function Preview({ id, auth, name }: { id: string; auth: string; name: string }) {
  const [src, setSrc] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    let url: string | null = null;
    fetch(`/api/admin/photos/${id}`, { headers: { Authorization: auth }, cache: 'no-store' })
      .then((res) => {
        if (!res.ok) throw new Error('falha');
        return res.blob();
      })
      .then((blob) => {
        if (cancelled) return;
        url = URL.createObjectURL(blob);
        setSrc(url);
      })
      .catch(() => {
        if (!cancelled) setFailed(true);
      });
    return () => {
      cancelled = true;
      if (url) URL.revokeObjectURL(url);
    };
  }, [id, auth]);

  if (src) return <img src={src} alt={`Prévia de ${name}`} loading="lazy" />;
  return <span>{failed ? 'Prévia indisponível' : 'Carregando…'}</span>;
}

export default function AdminPanel() {
  const [auth, setAuth] = useState<string | null>(null);
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const [items, setItems] = useState<PhotoRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [format, setFormat] = useState('');

  async function load(header: string) {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/admin/photos', { headers: { Authorization: header }, cache: 'no-store' });
      if (res.status === 401) {
        setAuth(null);
        setError('Usuário ou senha inválidos.');
        return;
      }
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Não foi possível carregar as fotos.');
      setItems(data.items as PhotoRecord[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Falha de conexão.');
    } finally {
      setLoading(false);
    }
  }

  function login(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const header = basicHeader(user, pass);
    setAuth(header);
    setPass('');
    void load(header);
  }

  function logout() {
    setAuth(null);
    setItems([]);
    setUser('');
    setError(null);
  }

  async function download(item: PhotoRecord) {
    if (!auth) return;
    try {
      const res = await fetch(`/api/admin/photos/${item.id}?download=1`, { headers: { Authorization: auth } });
      if (!res.ok) throw new Error();
      const url = URL.createObjectURL(await res.blob());
      const a = document.createElement('a');
      a.href = url;
      a.download = item.originalName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      setError('Não foi possível baixar o arquivo.');
    }
  }

  async function remove(item: PhotoRecord) {
    if (!auth) return;
    if (!window.confirm(`Excluir "${item.originalName}"? A foto e os metadados serão removidos permanentemente.`)) return;
    try {
      const res = await fetch(`/api/admin/photos/${item.id}`, { method: 'DELETE', headers: { Authorization: auth } });
      if (!res.ok) throw new Error();
      setItems((prev) => prev.filter((i) => i.id !== item.id));
    } catch {
      setError('Não foi possível excluir a foto.');
    }
  }

  const visible = useMemo(() => {
    const term = search.trim().toLowerCase();
    return items.filter((i) => {
      if (format && i.format !== format) return false;
      if (!term) return true;
      return [i.originalName, i.cameraMake, i.cameraModel].filter(Boolean).join(' ').toLowerCase().includes(term);
    });
  }, [items, search, format]);

  if (!auth) {
    return (
      <section className="card narrow" style={{ marginTop: 24 }}>
        <p className="eyebrow">Área restrita</p>
        <h1 style={{ fontSize: '1.6rem' }}>Entrar no painel</h1>
        <form onSubmit={login} style={{ display: 'grid', gap: 14, marginTop: 18 }}>
          <label className="field">
            Usuário
            <input className="input" value={user} onChange={(e) => setUser(e.target.value)} autoComplete="username" required />
          </label>
          <label className="field">
            Senha
            <input className="input" type="password" value={pass} onChange={(e) => setPass(e.target.value)} autoComplete="current-password" required />
          </label>
          {error && <p role="alert" className="alert" style={{ margin: 0 }}>{error}</p>}
          <button type="submit" className="btn btn-primary">Entrar</button>
        </form>
      </section>
    );
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 12, marginTop: 8 }}>
        <div>
          <p className="eyebrow">Área restrita</p>
          <h1 style={{ fontSize: '2rem' }}>Fotos recebidas</h1>
          <p className="muted">{items.length} {items.length === 1 ? 'foto' : 'fotos'} no total</p>
        </div>
        <button type="button" className="btn btn-ghost btn-small" onClick={logout}>Sair</button>
      </div>

      <div className="toolbar">
        <label className="field">
          Buscar
          <input className="input" placeholder="Nome, marca ou modelo" value={search} onChange={(e) => setSearch(e.target.value)} />
        </label>
        <label className="field" style={{ maxWidth: 200 }}>
          Formato
          <select className="input" value={format} onChange={(e) => setFormat(e.target.value)}>
            <option value="">Todos</option>
            <option value="jpeg">JPEG</option>
            <option value="png">PNG</option>
            <option value="webp">WebP</option>
            <option value="heic">HEIC</option>
          </select>
        </label>
      </div>

      {error && <p role="alert" className="alert">{error}</p>}
      {loading && items.length === 0 && <p className="muted">Carregando…</p>}
      {!loading && items.length === 0 && !error && <div className="empty">Nenhuma foto recebida ainda.</div>}
      {items.length > 0 && visible.length === 0 && <div className="empty">Nenhuma foto encontrada com esses filtros.</div>}

      <div className="grid">
        {visible.map((item) => (
          <article key={item.id} className="photo-card">
            <div className="preview">
              <Preview id={item.id} auth={auth} name={item.originalName} />
            </div>
            <div className="photo-body">
              <h3 title={item.originalName}>{item.originalName}</h3>
              <dl className="photo-meta">
                <div><dt>Enviada em</dt><dd>{formatDate(item.uploadedAt)}</dd></div>
                <div><dt>Formato</dt><dd>{item.format.toUpperCase()} · {formatBytes(item.sizeBytes)}</dd></div>
                <div><dt>Resolução</dt><dd>{formatResolution(item.width, item.height)}</dd></div>
                <div><dt>Dispositivo</dt><dd>{[item.cameraMake, item.cameraModel].filter(Boolean).join(' ') || 'Não informado'}</dd></div>
                <div>
                  <dt>GPS</dt>
                  <dd>{item.latitude !== null && item.longitude !== null ? `${item.latitude.toFixed(5)}, ${item.longitude.toFixed(5)}` : 'Ausente'}</dd>
                </div>
              </dl>
              <details>
                <summary className="muted" style={{ cursor: 'pointer' }}>Ver metadados</summary>
                <pre className="json">{JSON.stringify(item.metadata, null, 2)}</pre>
              </details>
              <div className="photo-actions">
                <button type="button" className="btn btn-ghost btn-small" onClick={() => download(item)}>Baixar original</button>
                <button type="button" className="btn btn-danger btn-small" onClick={() => remove(item)}>Excluir</button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
