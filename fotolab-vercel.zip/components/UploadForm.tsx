'use client';

import { useRef, useState, type DragEvent, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { upload } from '@vercel/blob/client';
import { detectFormat, extensionOf, validateFileMeta } from '@/lib/validate';
import { formatBytes } from '@/lib/format';

async function checkFile(file: File): Promise<string | null> {
  const metaError = validateFileMeta(file.name, file.size);
  if (metaError) return metaError;
  const head = new Uint8Array(await file.slice(0, 16).arrayBuffer());
  if (!detectFormat(head)) return 'O conteúdo não corresponde a JPG, PNG, WebP ou HEIC.';
  return null;
}

export default function UploadForm() {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [consent, setConsent] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  async function choose(candidate: File | undefined) {
    setError(null);
    if (!candidate) return;
    const problem = await checkFile(candidate);
    if (problem) {
      setFile(null);
      setError(problem);
      return;
    }
    setFile(candidate);
  }

  function onDrop(e: DragEvent<HTMLLabelElement>) {
    e.preventDefault();
    setDragging(false);
    void choose(e.dataTransfer.files?.[0]);
  }

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!file || !consent || busy) return;

    setBusy(true);
    setError(null);
    setProgress(0);
    try {
      const ext = extensionOf(file.name) || 'jpg';
      const blob = await upload(`uploads/photo.${ext}`, file, {
        access: 'private',
        handleUploadUrl: '/api/upload/token',
        clientPayload: JSON.stringify({ consent: true }),
        multipart: true,
        onUploadProgress: (p) => setProgress(Math.round(p.percentage)),
      });

      const res = await fetch('/api/images', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pathname: blob.pathname,
          url: blob.url,
          originalName: file.name,
          consent: true,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Não foi possível processar a imagem.');

      sessionStorage.setItem('fotolab:last-result', JSON.stringify(data.image));
      router.push('/resultado');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro inesperado. Tente novamente.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-6" noValidate>
      <label
        htmlFor="photo"
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        className={`flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border border-dashed px-6 py-12 text-center transition ${
          dragging ? 'border-accent bg-accent/10' : 'border-line hover:border-accent/70 hover:bg-white/[0.02]'
        }`}
      >
        <span className="text-base font-medium text-white">
          {file ? file.name : 'Arraste a foto aqui ou toque para escolher'}
        </span>
        <span className="text-sm text-slate-500">
          {file ? formatBytes(file.size) : 'JPG, JPEG, PNG, WebP ou HEIC · até 25 MB'}
        </span>
        <input
          ref={inputRef}
          id="photo"
          type="file"
          accept=".jpg,.jpeg,.png,.webp,.heic,image/jpeg,image/png,image/webp,image/heic"
          className="sr-only"
          onChange={(e) => void choose(e.target.files?.[0])}
        />
      </label>

      <label className="flex gap-3 text-sm leading-relaxed text-slate-400">
        <input
          type="checkbox"
          checked={consent}
          onChange={(e) => setConsent(e.target.checked)}
          className="mt-1 h-4 w-4 shrink-0 accent-blue-500"
        />
        <span>
          Entendo que a imagem será <strong className="text-slate-200">armazenada</strong> e poderá ser acessada pelo
          administrador autorizado deste site, junto com os metadados do arquivo, incluindo localização GPS se existir.
        </span>
      </label>

      {error && (
        <p role="alert" className="rounded-xl border border-red-900/60 bg-red-950/40 px-4 py-3 text-sm text-red-300">
          {error}
        </p>
      )}

      {busy && (
        <div className="space-y-2" aria-live="polite">
          <div className="h-1.5 overflow-hidden rounded-full bg-line">
            <div className="h-full bg-accent transition-all" style={{ width: `${progress}%` }} />
          </div>
          <p className="text-xs text-slate-500">Enviando e analisando… {progress}%</p>
        </div>
      )}

      <button type="submit" disabled={!file || !consent || busy} className="btn-primary w-full">
        {busy ? 'Enviando…' : 'Analisar foto'}
      </button>
    </form>
  );
}
