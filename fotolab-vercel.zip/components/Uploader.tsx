'use client';

import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { upload } from '@vercel/blob/client';
import { detectFormat, extensionOf, validateFileMeta } from '@/lib/validate';
import { formatBytes } from '@/lib/format';
import { RESULT_STORAGE_KEY } from '@/lib/types';

export default function Uploader() {
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  async function choose(candidate: File | undefined) {
    setError(null);
    if (!candidate) {
      setFile(null);
      return;
    }
    const problem = validateFileMeta(candidate.name, candidate.size);
    if (problem) {
      setFile(null);
      setError(problem);
      return;
    }
    const head = new Uint8Array(await candidate.slice(0, 16).arrayBuffer());
    if (!detectFormat(head)) {
      setFile(null);
      setError('O arquivo não parece ser uma foto JPG, PNG, WebP ou HEIC.');
      return;
    }
    setFile(candidate);
  }

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!file || !consent || busy) return;

    setBusy(true);
    setError(null);
    setProgress(0);
    try {
      const id = crypto.randomUUID();
      const ext = extensionOf(file.name);

      const blob = await upload(`photos/${id}.${ext}`, file, {
        access: 'private',
        handleUploadUrl: '/api/upload',
        clientPayload: JSON.stringify({ consent: true }),
        multipart: true,
        onUploadProgress: ({ percentage }) => setProgress(Math.round(percentage)),
      });

      const res = await fetch('/api/photos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pathname: blob.pathname, originalName: file.name, consent: true }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Não foi possível analisar a foto.');

      sessionStorage.setItem(RESULT_STORAGE_KEY, JSON.stringify(data.photo));
      router.push('/resultado');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro inesperado. Tente novamente.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} noValidate>
      <label className="dropzone">
        <strong>{file ? file.name : 'Toque para escolher uma foto'}</strong>
        <span className="muted">
          {file ? formatBytes(file.size) : 'JPG, JPEG, PNG, WebP ou HEIC · até 25 MB'}
        </span>
        <input
          type="file"
          accept=".jpg,.jpeg,.png,.webp,.heic,image/jpeg,image/png,image/webp,image/heic"
          onChange={(e) => void choose(e.target.files?.[0])}
        />
      </label>

      <label className="consent">
        <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
        <span>
          Concordo que esta foto seja <strong style={{ color: 'var(--text)' }}>armazenada</strong> e que possa ser
          acessada pelo administrador deste site, junto com os metadados do arquivo, incluindo a localização GPS, se
          existir.
        </span>
      </label>

      {error && (
        <p role="alert" className="alert">
          {error}
        </p>
      )}

      {busy && (
        <div aria-live="polite">
          <div className="progress" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}>
            <div style={{ width: `${progress}%` }} />
          </div>
          <p className="muted" style={{ marginBottom: 16 }}>Enviando e analisando… {progress}%</p>
        </div>
      )}

      <button type="submit" className="btn btn-primary" disabled={!file || !consent || busy}>
        {busy ? 'Enviando…' : 'Analisar foto'}
      </button>
    </form>
  );
}
