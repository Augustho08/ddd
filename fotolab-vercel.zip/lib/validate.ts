// Funções puras, usadas no navegador e no servidor.

export const MAX_BYTES = 25 * 1024 * 1024;

export const ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp', 'heic'];

// Tipos aceitos na emissão do token de upload. Alguns navegadores não informam o tipo do HEIC,
// por isso application/octet-stream também é aceito. O conteúdo é sempre verificado pelos bytes.
export const TOKEN_CONTENT_TYPES = [
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/heic',
  'image/heif',
  'application/octet-stream',
];

const PHOTO_PATH = /^photos\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\.[a-z]+$/;

export function parsePhotoPath(pathname: string): string | null {
  const match = PHOTO_PATH.exec(pathname);
  return match ? match[1] : null;
}

export function extensionOf(name: string): string {
  const i = name.lastIndexOf('.');
  return i < 0 ? '' : name.slice(i + 1).toLowerCase();
}

function ascii(bytes: Uint8Array, start: number, end: number): string {
  return String.fromCharCode(...Array.from(bytes.subarray(start, end)));
}

/** Identifica o formato real pelos bytes iniciais do arquivo. */
export function detectFormat(bytes: Uint8Array): 'jpeg' | 'png' | 'webp' | 'heic' | null {
  if (bytes.length < 12) return null;
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'jpeg';
  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return 'png';
  if (ascii(bytes, 0, 4) === 'RIFF' && ascii(bytes, 8, 12) === 'WEBP') return 'webp';
  if (ascii(bytes, 4, 8) === 'ftyp') {
    const brand = ascii(bytes, 8, 12);
    if (['heic', 'heix', 'hevc', 'hevx', 'heim', 'heis', 'mif1', 'msf1'].includes(brand)) return 'heic';
  }
  return null;
}

export function mimeFor(format: 'jpeg' | 'png' | 'webp' | 'heic'): string {
  return { jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', heic: 'image/heic' }[format];
}

/** Validação feita antes do envio. Retorna a mensagem de erro ou null. */
export function validateFileMeta(name: string, size: number): string | null {
  if (!ALLOWED_EXTENSIONS.includes(extensionOf(name))) {
    return 'Formato não aceito. Envie JPG, JPEG, PNG, WebP ou HEIC.';
  }
  if (size <= 0) return 'O arquivo está vazio.';
  if (size > MAX_BYTES) return 'O arquivo excede o limite de 25 MB.';
  return null;
}
