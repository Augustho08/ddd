// Funções puras (sem dependências de Node), usadas no cliente e no servidor.

export const MAX_UPLOAD_BYTES = 25 * 1024 * 1024; // 25 MB

export const ALLOWED_FORMATS = ['jpeg', 'png', 'webp', 'heic'] as const;
export type ImageFormat = (typeof ALLOWED_FORMATS)[number];

export const ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp', 'heic'] as const;

// Tipos aceitos na emissão do token de upload. Inclui application/octet-stream
// porque alguns navegadores não informam o tipo do HEIC; o conteúdo é sempre
// verificado pelos bytes do arquivo no servidor.
export const TOKEN_CONTENT_TYPES = [
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/heic',
  'image/heif',
  'application/octet-stream',
];

const HEIC_BRANDS = ['heic', 'heix', 'hevc', 'hevx', 'heim', 'heis', 'mif1', 'msf1'];

function ascii(bytes: Uint8Array, start: number, end: number): string {
  return String.fromCharCode(...Array.from(bytes.subarray(start, end)));
}

/** Identifica o formato real do arquivo pela assinatura (magic bytes). */
export function detectFormat(bytes: Uint8Array): ImageFormat | null {
  if (bytes.length < 12) return null;
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'jpeg';
  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return 'png';
  if (ascii(bytes, 0, 4) === 'RIFF' && ascii(bytes, 8, 12) === 'WEBP') return 'webp';
  if (ascii(bytes, 4, 8) === 'ftyp' && HEIC_BRANDS.includes(ascii(bytes, 8, 12))) return 'heic';
  return null;
}

export function extensionOf(name: string): string {
  const i = name.lastIndexOf('.');
  return i < 0 ? '' : name.slice(i + 1).toLowerCase();
}

export function mimeFor(format: ImageFormat): string {
  const map: Record<ImageFormat, string> = {
    jpeg: 'image/jpeg',
    png: 'image/png',
    webp: 'image/webp',
    heic: 'image/heic',
  };
  return map[format];
}

/** Valida nome e tamanho antes do envio. Retorna mensagem de erro ou null. */
export function validateFileMeta(name: string, size: number): string | null {
  const ext = extensionOf(name);
  if (!(ALLOWED_EXTENSIONS as readonly string[]).includes(ext)) {
    return 'Formato não aceito. Envie JPG, JPEG, PNG, WebP ou HEIC.';
  }
  if (size <= 0) return 'O arquivo está vazio.';
  if (size > MAX_UPLOAD_BYTES) return 'O arquivo excede o limite de 25 MB.';
  return null;
}
