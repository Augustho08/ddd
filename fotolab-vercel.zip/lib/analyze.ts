import 'server-only';
import sharp from 'sharp';
import exifr from 'exifr';

export interface Analysis {
  width: number | null;
  height: number | null;
  orientation: number | null;
  capturedAt: string | null;
  cameraMake: string | null;
  cameraModel: string | null;
  latitude: number | null;
  longitude: number | null;
  metadata: Record<string, unknown>;
  thumbnail: Buffer | null;
  warnings: string[];
}

const MAX_STRING = 500;

/** Converte os valores para JSON seguro: remove binários e limita textos longos. */
function sanitize(value: unknown, depth = 0): unknown {
  if (value === null || value === undefined) return undefined;
  if (value instanceof Date) return isNaN(value.getTime()) ? undefined : value.toISOString();
  if (value instanceof Uint8Array || value instanceof ArrayBuffer) return undefined;
  if (typeof value === 'string') return value.length > MAX_STRING ? `${value.slice(0, MAX_STRING)}…` : value;
  if (typeof value === 'number') return Number.isFinite(value) ? value : undefined;
  if (typeof value === 'boolean') return value;
  if (Array.isArray(value)) {
    return value.slice(0, 50).map((v) => sanitize(v, depth + 1)).filter((v) => v !== undefined);
  }
  if (typeof value === 'object' && depth < 3) {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (k === 'MakerNote' || k === 'UserComment') continue;
      const s = sanitize(v, depth + 1);
      if (s !== undefined) out[k] = s;
    }
    return Object.keys(out).length ? out : undefined;
  }
  return undefined;
}

function asString(value: unknown): string | null {
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

/** Extrai dimensões, metadados EXIF/IPTC/XMP, GPS e gera miniatura. Nunca lança erro. */
export async function analyzeImage(buffer: Buffer): Promise<Analysis> {
  const warnings: string[] = [];

  let width: number | null = null;
  let height: number | null = null;
  let orientation: number | null = null;
  try {
    const meta = await sharp(buffer).metadata();
    width = meta.width ?? null;
    height = meta.height ?? null;
    orientation = meta.orientation ?? null;
  } catch {
    warnings.push('As dimensões não puderam ser lidas com o decodificador de imagem.');
  }

  // Orientações 5 a 8 giram a imagem 90°, então largura e altura se invertem.
  if (orientation && orientation >= 5 && orientation <= 8 && width && height) {
    [width, height] = [height, width];
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let raw: Record<string, any> = {};
  try {
    raw =
      (await exifr.parse(buffer, {
        mergeOutput: false,
        tiff: true,
        ifd0: true,
        exif: true,
        gps: true,
        xmp: true,
        iptc: true,
        icc: false,
        jfif: false,
        ihdr: false,
        makerNote: false,
        userComment: false,
        ifd1: false,
        interop: false,
      })) ?? {};
  } catch {
    warnings.push('Não foi possível ler os metadados desta imagem.');
  }

  let latitude: number | null = null;
  let longitude: number | null = null;
  try {
    const coords = await exifr.gps(buffer);
    if (coords && typeof coords.latitude === 'number' && typeof coords.longitude === 'number') {
      latitude = coords.latitude;
      longitude = coords.longitude;
    }
  } catch {
    // Sem GPS válido: o campo permanece nulo.
  }

  const exifWidth = raw.exif?.ExifImageWidth ?? raw.ifd0?.ImageWidth;
  const exifHeight = raw.exif?.ExifImageHeight ?? raw.ifd0?.ImageHeight;
  if (!width && typeof exifWidth === 'number') width = exifWidth;
  if (!height && typeof exifHeight === 'number') height = exifHeight;

  const captured = raw.exif?.DateTimeOriginal ?? raw.exif?.CreateDate ?? raw.ifd0?.DateTime;
  const capturedAt = captured instanceof Date && !isNaN(captured.getTime()) ? captured.toISOString() : null;

  let thumbnail: Buffer | null = null;
  try {
    thumbnail = await sharp(buffer)
      .rotate()
      .resize({ width: 640, height: 640, fit: 'inside', withoutEnlargement: true })
      .jpeg({ quality: 82 })
      .toBuffer();
  } catch {
    warnings.push('Miniatura indisponível para este formato. A imagem original continua disponível.');
  }

  const groups: Record<string, unknown> = {};
  for (const key of ['ifd0', 'exif', 'gps', 'xmp', 'iptc'] as const) {
    const cleaned = sanitize(raw[key]);
    if (cleaned !== undefined) groups[key] = cleaned;
  }

  return {
    width,
    height,
    orientation,
    capturedAt,
    cameraMake: asString(raw.ifd0?.Make),
    cameraModel: asString(raw.ifd0?.Model),
    latitude,
    longitude,
    metadata: groups,
    thumbnail,
    warnings,
  };
}
