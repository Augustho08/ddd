import exifr from 'exifr';
import sizeOf from 'image-size';

export interface Analysis {
  width: number | null;
  height: number | null;
  capturedAt: string | null;
  cameraMake: string | null;
  cameraModel: string | null;
  latitude: number | null;
  longitude: number | null;
  metadata: Record<string, unknown>;
}

const MAX_TEXT = 300;

/** Remove binários e limita textos longos, para que o resultado seja JSON seguro. */
function clean(value: unknown, depth = 0): unknown {
  if (value === null || value === undefined) return undefined;
  if (value instanceof Date) return isNaN(value.getTime()) ? undefined : value.toISOString();
  if (value instanceof Uint8Array) return undefined;
  if (typeof value === 'string') return value.length > MAX_TEXT ? `${value.slice(0, MAX_TEXT)}…` : value;
  if (typeof value === 'number') return Number.isFinite(value) ? value : undefined;
  if (typeof value === 'boolean') return value;
  if (Array.isArray(value)) {
    return value
      .slice(0, 30)
      .map((v) => clean(v, depth + 1))
      .filter((v) => v !== undefined);
  }
  if (typeof value === 'object' && depth < 3) {
    const out: Record<string, unknown> = {};
    for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
      if (key === 'MakerNote' || key === 'UserComment') continue;
      const cleaned = clean(item, depth + 1);
      if (cleaned !== undefined) out[key] = cleaned;
    }
    return Object.keys(out).length > 0 ? out : undefined;
  }
  return undefined;
}

function text(value: unknown): string | null {
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

export async function analyzeImage(buffer: Buffer): Promise<Analysis> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let raw: Record<string, any> = {};
  try {
    raw =
      (await exifr.parse(buffer, {
        mergeOutput: false,
        tiff: true,
        ifd0: true,
        exif: true,
        gps: true,
        xmp: true,
        iptc: true,
        icc: false,
        jfif: false,
        ihdr: false,
        makerNote: false,
        userComment: false,
        ifd1: false,
        interop: false,
      })) ?? {};
  } catch {
    raw = {};
  }

  let width: number | null = null;
  let height: number | null = null;
  try {
    const size = sizeOf(buffer);
    width = size.width ?? null;
    height = size.height ?? null;
  } catch {
    // Formato sem leitura de dimensões: tenta os campos EXIF abaixo.
  }
  if (!width && typeof raw.exif?.ExifImageWidth === 'number') width = raw.exif.ExifImageWidth;
  if (!height && typeof raw.exif?.ExifImageHeight === 'number') height = raw.exif.ExifImageHeight;

  // Orientações 5 a 8 giram a imagem 90 graus, então largura e altura se trocam.
  const orientation = raw.ifd0?.Orientation;
  if (width && height && typeof orientation === 'number' && orientation >= 5 && orientation <= 8) {
    [width, height] = [height, width];
  }

  let latitude: number | null = null;
  let longitude: number | null = null;
  try {
    const coords = await exifr.gps(buffer);
    if (coords && typeof coords.latitude === 'number' && typeof coords.longitude === 'number') {
      latitude = coords.latitude;
      longitude = coords.longitude;
    }
  } catch {
    // Sem GPS legível: os campos permanecem nulos.
  }

  const captured = raw.exif?.DateTimeOriginal ?? raw.exif?.CreateDate ?? raw.ifd0?.DateTime;
  const capturedAt = captured instanceof Date && !isNaN(captured.getTime()) ? captured.toISOString() : null;

  const metadata: Record<string, unknown> = {};
  for (const group of ['ifd0', 'exif', 'gps', 'xmp', 'iptc']) {
    const cleaned = clean(raw[group]);
    if (cleaned !== undefined) metadata[group] = cleaned;
  }

  return {
    width,
    height,
    capturedAt,
    cameraMake: text(raw.ifd0?.Make),
    cameraModel: text(raw.ifd0?.Model),
    latitude,
    longitude,
    metadata,
  };
}
