import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { COOKIE_NAME, verifySession } from './session';

/** Retorna null se o administrador estiver autenticado; caso contrário, resposta 401. */
export async function requireAdmin(): Promise<NextResponse | null> {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (token && (await verifySession(token))) return null;
  return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
}
