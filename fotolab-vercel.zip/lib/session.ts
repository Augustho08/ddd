// Código compatível com Edge (usado pelo middleware): somente jose, sem Node APIs.
import { SignJWT, jwtVerify } from 'jose';

export const COOKIE_NAME = 'fotolab_admin';
export const SESSION_MAX_AGE = 60 * 60 * 8; // 8 horas

function secret(): Uint8Array {
  const value = process.env.SESSION_SECRET;
  if (!value || value.length < 32) {
    throw new Error('SESSION_SECRET ausente ou com menos de 32 caracteres.');
  }
  return new TextEncoder().encode(value);
}

export async function signSession(subject: string): Promise<string> {
  return new SignJWT({ role: 'admin' })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(subject)
    .setIssuedAt()
    .setExpirationTime(`${SESSION_MAX_AGE}s`)
    .sign(secret());
}

export async function verifySession(token: string): Promise<boolean> {
  try {
    const { payload } = await jwtVerify(token, secret(), { algorithms: ['HS256'] });
    return payload.role === 'admin';
  } catch {
    return false;
  }
}
