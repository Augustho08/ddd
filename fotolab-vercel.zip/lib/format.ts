export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KB', 'MB', 'GB'];
  let value = bytes / 1024;
  let i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i++;
  }
  return `${value.toFixed(value < 10 ? 1 : 0)} ${units[i]}`;
}

export function formatDate(iso: string | null): string {
  if (!iso) return 'Não informada';
  return new Date(iso).toLocaleString('pt-BR', { dateStyle: 'medium', timeStyle: 'short' });
}

export function formatResolution(width: number | null, height: number | null): string {
  if (!width || !height) return 'Não identificada';
  const mp = (width * height) / 1_000_000;
  return `${width} × ${height} px (${mp.toFixed(1)} MP)`;
}
