import { del, get, list } from '@vercel/blob';
import type { PhotoRecord } from './types';

/** Lê um registro JSON privado. Retorna null se não existir ou estiver corrompido. */
export async function readRecord(pathname: string): Promise<PhotoRecord | null> {
  const result = await get(pathname, { access: 'private' });
  if (!result || !result.stream) return null;
  try {
    return JSON.parse(await new Response(result.stream).text()) as PhotoRecord;
  } catch {
    return null;
  }
}

/** URLs de todos os blobs cujo caminho começa com o prefixo informado. */
export async function urlsWithPrefix(prefix: string): Promise<string[]> {
  const { blobs } = await list({ prefix });
  return blobs.filter((b) => b.pathname.startsWith(prefix)).map((b) => b.url);
}

export async function deleteWithPrefixes(prefixes: string[]): Promise<number> {
  const urls: string[] = [];
  for (const prefix of prefixes) {
    urls.push(...(await urlsWithPrefix(prefix)));
  }
  if (urls.length > 0) await del(urls);
  return urls.length;
}
