export interface PhotoRecord {
  id: string;
  pathname: string;
  originalName: string;
  format: 'jpeg' | 'png' | 'webp' | 'heic';
  mimeType: string;
  sizeBytes: number;
  width: number | null;
  height: number | null;
  capturedAt: string | null;
  cameraMake: string | null;
  cameraModel: string | null;
  latitude: number | null;
  longitude: number | null;
  uploadedAt: string;
  metadata: Record<string, unknown>;
}

export const RESULT_STORAGE_KEY = 'fotolab:resultado';
