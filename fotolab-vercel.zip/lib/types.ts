export interface ImageRecord {
  id: string;
  originalName: string;
  mimeType: string;
  format: string;
  sizeBytes: number;
  width: number | null;
  height: number | null;
  capturedAt: string | null;
  cameraMake: string | null;
  cameraModel: string | null;
  latitude: number | null;
  longitude: number | null;
  hasThumbnail: boolean;
  uploadedAt: string;
  metadata: Record<string, unknown>;
}

export interface ImagesPage {
  items: ImageRecord[];
  total: number;
  page: number;
  limit: number;
}
