import { createHash, timingSafeEqual } from 'node:crypto';
import { NextResponse } from 'next/server';

function digest(value: string): Buffer {
  return createHash('sha256').update(value, 'utf8').digest();
}

/** Verifica o cabeçalho Authorization: Basic contra ADMIN_USERNAME e ADMIN_PASSWORD. */
export function isAdmin(request: Request): boolean {
  const user = process.env.ADMIN_USERNAME;
  const pass = process.env.ADMIN_PASSWORD;
  if (!user || !pass) return false;

  const header = request.headers.get('authorization') ?? '';
  if (!header.startsWith('Basic ')) return false;

  const decoded = Buffer.from(header.slice(6), 'base64').toString('utf8');
  const separator = decoded.indexOf(':');
  if (separator < 0) return false;

  const givenUser = decoded.slice(0, separator);
  const givenPass = decoded.slice(separator + 1);

  const userOk = timingSafeEqual(digest(givenUser), digest(user));
  const passOk = timingSafeEqual(digest(givenPass), digest(pass));
  return userOk && passOk;
}

export function unauthorized(): NextResponse {
  return NextResponse.json({ error: 'Usuário ou senha inválidos.' }, { status: 401 });
}
