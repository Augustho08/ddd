import 'server-only';
import { neon } from '@neondatabase/serverless';
import type { ImageRecord } from './types';

export function getSql() {
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error('DATABASE_URL não configurada.');
  return neon(url);
}

let schemaReady: Promise<void> | null = null;

/** Cria a tabela na primeira utilização (idempotente). */
export function ensureSchema(): Promise<void> {
  if (!schemaReady) {
    schemaReady = (async () => {
      const sql = getSql();
      await sql`
        CREATE TABLE IF NOT EXISTS images (
          id uuid PRIMARY KEY,
          original_name text NOT NULL,
          mime_type text NOT NULL,
          format text NOT NULL,
          size_bytes integer NOT NULL,
          width integer,
          height integer,
          captured_at timestamptz,
          camera_make text,
          camera_model text,
          latitude double precision,
          longitude double precision,
          blob_url text NOT NULL,
          blob_pathname text NOT NULL,
          thumb_url text,
          thumb_pathname text,
          metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
          uploaded_at timestamptz NOT NULL DEFAULT now()
        )`;
      await sql`CREATE INDEX IF NOT EXISTS images_uploaded_idx ON images (uploaded_at DESC)`;
    })().catch((err) => {
      schemaReady = null;
      throw err;
    });
  }
  return schemaReady;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function toRecord(r: Record<string, any>): ImageRecord {
  return {
    id: r.id,
    originalName: r.original_name,
    mimeType: r.mime_type,
    format: r.format,
    sizeBytes: Number(r.size_bytes),
    width: r.width ?? null,
    height: r.height ?? null,
    capturedAt: r.captured_at ? new Date(r.captured_at).toISOString() : null,
    cameraMake: r.camera_make ?? null,
    cameraModel: r.camera_model ?? null,
    latitude: r.latitude ?? null,
    longitude: r.longitude ?? null,
    hasThumbnail: Boolean(r.thumb_pathname),
    uploadedAt: new Date(r.uploaded_at).toISOString(),
    metadata: r.metadata ?? {},
  };
}

export interface NewImage {
  id: string;
  originalName: string;
  mimeType: string;
  format: string;
  sizeBytes: number;
  width: number | null;
  height: number | null;
  capturedAt: string | null;
  cameraMake: string | null;
  cameraModel: string | null;
  latitude: number | null;
  longitude: number | null;
  blobUrl: string;
  blobPathname: string;
  thumbUrl: string | null;
  thumbPathname: string | null;
  metadata: Record<string, unknown>;
}

export async function insertImage(img: NewImage): Promise<ImageRecord> {
  const sql = getSql();
  const rows = await sql`
    INSERT INTO images (
      id, original_name, mime_type, format, size_bytes, width, height, captured_at,
      camera_make, camera_model, latitude, longitude,
      blob_url, blob_pathname, thumb_url, thumb_pathname, metadata
    ) VALUES (
      ${img.id}, ${img.originalName}, ${img.mimeType}, ${img.format}, ${img.sizeBytes},
      ${img.width}, ${img.height}, ${img.capturedAt},
      ${img.cameraMake}, ${img.cameraModel}, ${img.latitude}, ${img.longitude},
      ${img.blobUrl}, ${img.blobPathname}, ${img.thumbUrl}, ${img.thumbPathname},
      ${JSON.stringify(img.metadata)}::jsonb
    )
    RETURNING *`;
  return toRecord(rows[0]);
}

export interface ListFilters {
  q: string | null;
  format: string | null;
  from: string | null;
  to: string | null;
  limit: number;
  offset: number;
}

export async function listImages(f: ListFilters): Promise<{ items: ImageRecord[]; total: number }> {
  const sql = getSql();
  const q = f.q ? `%${f.q.replace(/[\\%_]/g, (m) => '\\' + m)}%` : null;
  const rows = await sql`
    SELECT *, COUNT(*) OVER() AS total_count
    FROM images
    WHERE (${q}::text IS NULL OR original_name ILIKE ${q} OR camera_model ILIKE ${q} OR camera_make ILIKE ${q})
      AND (${f.format}::text IS NULL OR format = ${f.format})
      AND (${f.from}::timestamptz IS NULL OR uploaded_at >= ${f.from}::timestamptz)
      AND (${f.to}::timestamptz IS NULL OR uploaded_at < ${f.to}::timestamptz)
    ORDER BY uploaded_at DESC
    LIMIT ${f.limit} OFFSET ${f.offset}`;
  const total = rows.length ? Number(rows[0].total_count) : 0;
  return { items: rows.map(toRecord), total };
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function getImageRow(id: string): Promise<Record<string, any> | null> {
  const sql = getSql();
  const rows = await sql`SELECT * FROM images WHERE id = ${id}`;
  return rows[0] ?? null;
}

export async function deleteImageRow(id: string): Promise<void> {
  const sql = getSql();
  await sql`DELETE FROM images WHERE id = ${id}`;
}
