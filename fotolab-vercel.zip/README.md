# FotoLab

Envie uma foto e veja formato, resolução, data de captura, dispositivo e coordenadas GPS (quando existirem). Um painel privado permite visualizar, baixar o original e excluir as fotos recebidas.

## Publicar na Vercel

1. **Envie o projeto ao GitHub.** Descompacte o ZIP e crie um repositório privado com o conteúdo.
2. **Importe na Vercel.** Em *Add New > Project*, escolha o repositório. O framework é detectado como Next.js.
3. **Crie o armazenamento.** Antes do deploy, abra *Storage > Create > Blob* e escolha **Private**. Depois, conecte-o ao projeto. Isso cria a variável `BLOB_READ_WRITE_TOKEN` automaticamente.
4. **Defina as credenciais do painel.** Em *Settings > Environment Variables*, adicione:
   - `ADMIN_USERNAME`: usuário do painel
   - `ADMIN_PASSWORD`: senha forte
5. **Faça o deploy.** Se você adicionou as variáveis depois do primeiro deploy, use *Redeploy*.

Acesse `https://seu-projeto.vercel.app/admin` para entrar no painel.

> O Blob privado precisa ser do tipo **Private**. Um store público não funciona com este projeto. Confira os limites do plano gratuito na documentação da Vercel.

## Executar localmente

```bash
npm install
cp .env.example .env.local   # preencha as variáveis
npm run dev
```

Para o armazenamento funcionar localmente, copie `BLOB_READ_WRITE_TOKEN` do painel da Vercel para o `.env.local`.

## Segurança

- As fotos ficam em armazenamento privado, sem URL pública.
- Os arquivos e os metadados só são entregues pela API, com autenticação HTTP Basic verificada no servidor a cada requisição.
- O painel guarda usuário e senha apenas na memória da aba. Ao recarregar a página, é preciso entrar de novo.
- O tipo do arquivo é verificado pelos bytes, não só pela extensão. Arquivos inválidos são apagados.
- O envio exige o consentimento explícito do usuário.

## Limitações

- Não há limite de tentativas de login. Use uma senha forte.
- Não há limite de envios por pessoa.
- Se o envio for confirmado no navegador, mas a análise falhar, o arquivo pode ficar no Blob sem registro. Remova-o pelo painel de Storage da Vercel.
- A listagem lê até 1.000 registros. Para um volume maior, seria preciso paginar.
- A prévia de HEIC depende do navegador. Em navegadores sem suporte, aparece uma mensagem no lugar da imagem.
