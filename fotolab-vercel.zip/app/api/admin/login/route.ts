import { NextResponse } from 'next/server';
import { createHash, timingSafeEqual } from 'node:crypto';
import { COOKIE_NAME, SESSION_MAX_AGE, signSession } from '@/lib/session';

export const runtime = 'nodejs';

function digestEqual(a: string, b: string): boolean {
  const ha = createHash('sha256').update(a).digest();
  const hb = createHash('sha256').update(b).digest();
  return timingSafeEqual(ha, hb);
}

export async function POST(req: Request) {
  const adminUser = process.env.ADMIN_USERNAME;
  const adminPass = process.env.ADMIN_PASSWORD;
  if (!adminUser || !adminPass) {
    return NextResponse.json({ error: 'Painel não configurado no servidor.' }, { status: 500 });
  }

  let body: { username?: unknown; password?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Requisição inválida.' }, { status: 400 });
  }

  const username = typeof body.username === 'string' ? body.username : '';
  const password = typeof body.password === 'string' ? body.password : '';
  const ok = digestEqual(username, adminUser) && digestEqual(password, adminPass);

  if (!ok) {
    // Atraso fixo dificulta tentativas em massa.
    await new Promise((resolve) => setTimeout(resolve, 900));
    return NextResponse.json({ error: 'Usuário ou senha inválidos.' }, { status: 401 });
  }

  const token = await signSession(username);
  const res = NextResponse.json({ ok: true });
  res.cookies.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    path: '/',
    maxAge: SESSION_MAX_AGE,
  });
  return res;
}
