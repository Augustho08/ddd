import { NextResponse } from 'next/server';
import { get } from '@vercel/blob';
import { requireAdmin } from '@/lib/admin-guard';
import { ensureSchema, getImageRow } from '@/lib/db';

export const runtime = 'nodejs';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const denied = await requireAdmin();
  if (denied) return denied;

  const { id } = await ctx.params;
  if (!UUID.test(id)) return NextResponse.json({ error: 'Identificador inválido.' }, { status: 400 });

  await ensureSchema();
  const row = await getImageRow(id);
  if (!row || !row.thumb_pathname) return NextResponse.json({ error: 'Miniatura indisponível.' }, { status: 404 });

  const stored = await get(row.thumb_pathname, { access: 'private' });
  if (!stored || !stored.stream) return NextResponse.json({ error: 'Miniatura ausente.' }, { status: 404 });

  return new Response(stored.stream, {
    headers: {
      'Content-Type': 'image/jpeg',
      'Cache-Control': 'private, max-age=3600',
      'X-Content-Type-Options': 'nosniff',
    },
  });
}
