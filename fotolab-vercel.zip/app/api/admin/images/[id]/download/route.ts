import { NextResponse } from 'next/server';
import { get } from '@vercel/blob';
import { requireAdmin } from '@/lib/admin-guard';
import { ensureSchema, getImageRow } from '@/lib/db';

export const runtime = 'nodejs';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Entrega o arquivo original byte a byte, com todos os metadados preservados.
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const denied = await requireAdmin();
  if (denied) return denied;

  const { id } = await ctx.params;
  if (!UUID.test(id)) return NextResponse.json({ error: 'Identificador inválido.' }, { status: 400 });

  await ensureSchema();
  const row = await getImageRow(id);
  if (!row) return NextResponse.json({ error: 'Imagem não encontrada.' }, { status: 404 });

  const stored = await get(row.blob_pathname, { access: 'private' });
  if (!stored || !stored.stream) return NextResponse.json({ error: 'Arquivo ausente.' }, { status: 404 });

  const asciiName = String(row.original_name).replace(/[^\x20-\x7e]/g, '_').replace(/"/g, '');
  const utf8Name = encodeURIComponent(String(row.original_name));

  return new Response(stored.stream, {
    headers: {
      'Content-Type': row.mime_type,
      'Content-Length': String(row.size_bytes),
      'Content-Disposition': `attachment; filename="${asciiName}"; filename*=UTF-8''${utf8Name}`,
      'Cache-Control': 'private, no-store',
      'X-Content-Type-Options': 'nosniff',
    },
  });
}
