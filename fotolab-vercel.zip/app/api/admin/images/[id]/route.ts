import { NextResponse } from 'next/server';
import { del } from '@vercel/blob';
import { requireAdmin } from '@/lib/admin-guard';
import { deleteImageRow, ensureSchema, getImageRow } from '@/lib/db';

export const runtime = 'nodejs';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const denied = await requireAdmin();
  if (denied) return denied;

  const { id } = await ctx.params;
  if (!UUID.test(id)) return NextResponse.json({ error: 'Identificador inválido.' }, { status: 400 });

  await ensureSchema();
  const row = await getImageRow(id);
  if (!row) return NextResponse.json({ error: 'Imagem não encontrada.' }, { status: 404 });

  // Remove os arquivos antes do registro: se falhar, o admin pode tentar de novo.
  const urls = [row.blob_url, row.thumb_url].filter((u): u is string => typeof u === 'string' && u.length > 0);
  await del(urls);
  await deleteImageRow(id);

  return NextResponse.json({ ok: true });
}
