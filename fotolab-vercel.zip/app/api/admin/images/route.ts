import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-guard';
import { ensureSchema, listImages } from '@/lib/db';
import { ALLOWED_FORMATS } from '@/lib/validate';

export const runtime = 'nodejs';

const LIMIT = 24;

function dateParam(value: string | null): string | null {
  return value && /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : null;
}

export async function GET(req: Request) {
  const denied = await requireAdmin();
  if (denied) return denied;

  const url = new URL(req.url);
  const q = (url.searchParams.get('q') ?? '').trim().slice(0, 100) || null;
  const rawFormat = url.searchParams.get('format') ?? '';
  const format = (ALLOWED_FORMATS as readonly string[]).includes(rawFormat) ? rawFormat : null;
  const from = dateParam(url.searchParams.get('from'));
  const toDay = dateParam(url.searchParams.get('to'));

  // "até" é inclusivo: consulta até o início do dia seguinte.
  let to: string | null = null;
  if (toDay) {
    const d = new Date(`${toDay}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() + 1);
    to = d.toISOString();
  }

  const page = Math.max(1, Number.parseInt(url.searchParams.get('page') ?? '1', 10) || 1);

  await ensureSchema();
  const { items, total } = await listImages({
    q,
    format,
    from,
    to,
    limit: LIMIT,
    offset: (page - 1) * LIMIT,
  });

  return NextResponse.json({ items, total, page, limit: LIMIT });
}
