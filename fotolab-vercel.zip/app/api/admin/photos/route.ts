import { NextResponse } from 'next/server';
import { list } from '@vercel/blob';
import { isAdmin, unauthorized } from '@/lib/auth';
import { readRecord } from '@/lib/blob';
import type { PhotoRecord } from '@/lib/types';

export const runtime = 'nodejs';

// Lista os registros recebidos, do mais recente para o mais antigo.
export async function GET(req: Request) {
  if (!isAdmin(req)) return unauthorized();

  try {
    const { blobs } = await list({ prefix: 'meta/' });
    const records = await Promise.all(
      blobs.map((b) => readRecord(b.pathname).catch(() => null)),
    );
    const items = records
      .filter((r): r is PhotoRecord => r !== null)
      .sort((a, b) => b.uploadedAt.localeCompare(a.uploadedAt));
    return NextResponse.json({ items });
  } catch {
    return NextResponse.json({ error: 'Não foi possível carregar as fotos.' }, { status: 500 });
  }
}
