import { NextResponse } from 'next/server';
import { get } from '@vercel/blob';
import { isAdmin, unauthorized } from '@/lib/auth';
import { deleteWithPrefixes, readRecord } from '@/lib/blob';

export const runtime = 'nodejs';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

type Context = { params: Promise<{ id: string }> };

function asciiName(name: string): string {
  return name.replace(/[^\x20-\x7e]/g, '_').replace(/"/g, '');
}

// Entrega o arquivo original sem alterações. Com ?download=1, força o download.
export async function GET(req: Request, ctx: Context) {
  if (!isAdmin(req)) return unauthorized();

  const { id } = await ctx.params;
  if (!UUID.test(id)) return NextResponse.json({ error: 'Identificador inválido.' }, { status: 400 });

  try {
    const record = await readRecord(`meta/${id}.json`);
    if (!record) return NextResponse.json({ error: 'Foto não encontrada.' }, { status: 404 });

    const file = await get(record.pathname, { access: 'private' });
    if (!file || !file.stream) return NextResponse.json({ error: 'Arquivo ausente.' }, { status: 404 });

    const download = new URL(req.url).searchParams.get('download') === '1';
    const disposition = download ? 'attachment' : 'inline';
    const name = record.originalName;

    return new Response(file.stream, {
      headers: {
        'Content-Type': record.mimeType,
        'Content-Length': String(record.sizeBytes),
        'Content-Disposition': `${disposition}; filename="${asciiName(name)}"; filename*=UTF-8''${encodeURIComponent(name)}`,
        'Cache-Control': 'private, no-store',
        'X-Content-Type-Options': 'nosniff',
      },
    });
  } catch {
    return NextResponse.json({ error: 'Arquivo indisponível.' }, { status: 404 });
  }
}

// Remove o arquivo original e o registro de metadados.
export async function DELETE(req: Request, ctx: Context) {
  if (!isAdmin(req)) return unauthorized();

  const { id } = await ctx.params;
  if (!UUID.test(id)) return NextResponse.json({ error: 'Identificador inválido.' }, { status: 400 });

  try {
    const removed = await deleteWithPrefixes([`photos/${id}.`, `meta/${id}.json`]);
    if (removed === 0) return NextResponse.json({ error: 'Foto não encontrada.' }, { status: 404 });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: 'Não foi possível excluir a foto.' }, { status: 500 });
  }
}
