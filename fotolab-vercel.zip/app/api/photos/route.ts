import { NextResponse } from 'next/server';
import { del, put, get } from '@vercel/blob';
import { analyzeImage } from '@/lib/analyze';
import { readRecord, urlsWithPrefix } from '@/lib/blob';
import type { PhotoRecord } from '@/lib/types';
import { MAX_BYTES, detectFormat, mimeFor, parsePhotoPath } from '@/lib/validate';

export const runtime = 'nodejs';
export const maxDuration = 60;

function safeName(name: string): string {
  const cleaned = name.replace(/[\\/:*?"<>|\x00-\x1f]/g, '_').trim().slice(0, 120);
  return cleaned || 'foto';
}

// Confirma o envio: lê o arquivo, valida o conteúdo real, extrai os metadados e grava o registro.
export async function POST(req: Request) {
  let body: { pathname?: unknown; originalName?: unknown; consent?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Requisição inválida.' }, { status: 400 });
  }

  if (body.consent !== true) {
    return NextResponse.json({ error: 'É preciso concordar com o armazenamento da foto.' }, { status: 400 });
  }

  const pathname = typeof body.pathname === 'string' ? body.pathname : '';
  const id = parsePhotoPath(pathname);
  if (!id) {
    return NextResponse.json({ error: 'Arquivo não encontrado.' }, { status: 400 });
  }

  const stored = await get(pathname, { access: 'private' });
  if (!stored || !stored.stream) {
    return NextResponse.json({ error: 'Arquivo não encontrado.' }, { status: 404 });
  }
  const buffer = Buffer.from(await new Response(stored.stream).arrayBuffer());

  const format = detectFormat(buffer);
  if (!format || buffer.length > MAX_BYTES) {
    // Arquivo inválido: remove do armazenamento antes de responder.
    const urls = await urlsWithPrefix(pathname);
    if (urls.length > 0) await del(urls);
    return NextResponse.json(
      { error: 'O arquivo não é uma foto JPG, PNG, WebP ou HEIC válida.' },
      { status: 415 },
    );
  }

  const analysis = await analyzeImage(buffer);

  const record: PhotoRecord = {
    id,
    pathname,
    originalName: safeName(typeof body.originalName === 'string' ? body.originalName : 'foto'),
    format,
    mimeType: mimeFor(format),
    sizeBytes: buffer.length,
    width: analysis.width,
    height: analysis.height,
    capturedAt: analysis.capturedAt,
    cameraMake: analysis.cameraMake,
    cameraModel: analysis.cameraModel,
    latitude: analysis.latitude,
    longitude: analysis.longitude,
    uploadedAt: new Date().toISOString(),
    metadata: analysis.metadata,
  };

  await put(`meta/${id}.json`, JSON.stringify(record), {
    access: 'private',
    contentType: 'application/json',
    addRandomSuffix: false,
  });

  // Confirma que o registro existe antes de responder.
  const saved = await readRecord(`meta/${id}.json`);
  if (!saved) {
    return NextResponse.json({ error: 'Não foi possível salvar a análise.' }, { status: 500 });
  }

  return NextResponse.json({ photo: saved });
}
