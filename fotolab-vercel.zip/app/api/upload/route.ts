import { NextResponse } from 'next/server';
import { handleUpload, type HandleUploadBody } from '@vercel/blob/client';
import { MAX_BYTES, TOKEN_CONTENT_TYPES, parsePhotoPath } from '@/lib/validate';

// Emite a autorização para o navegador enviar a foto direto ao Blob privado.
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as HandleUploadBody;
    const json = await handleUpload({
      body,
      request,
      onBeforeGenerateToken: async (pathname, clientPayload) => {
        let consent = false;
        try {
          consent = JSON.parse(clientPayload ?? '{}').consent === true;
        } catch {
          consent = false;
        }
        if (!consent) {
          throw new Error('É preciso concordar com o armazenamento da foto.');
        }
        if (!parsePhotoPath(pathname)) {
          throw new Error('Nome de arquivo inválido.');
        }
        return {
          allowedContentTypes: TOKEN_CONTENT_TYPES,
          maximumSizeInBytes: MAX_BYTES,
          addRandomSuffix: false,
        };
      },
      onUploadCompleted: async () => {
        // A análise é feita em /api/photos, após a confirmação do navegador.
      },
    });
    return NextResponse.json(json);
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Não foi possível autorizar o envio.';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
