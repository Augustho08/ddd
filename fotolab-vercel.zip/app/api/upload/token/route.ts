import { NextResponse } from 'next/server';
import { handleUpload, type HandleUploadBody } from '@vercel/blob/client';
import { MAX_UPLOAD_BYTES, TOKEN_CONTENT_TYPES } from '@/lib/validate';

export const runtime = 'nodejs';

// Emite tokens para upload direto do navegador ao Blob privado.
// Isso evita o limite de ~4,5 MB do corpo de requisições na Vercel.
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as HandleUploadBody;
    const json = await handleUpload({
      body,
      request,
      onBeforeGenerateToken: async (pathname, clientPayload) => {
        let payload: { consent?: boolean } = {};
        try {
          payload = JSON.parse(clientPayload ?? '{}');
        } catch {
          throw new Error('Payload inválido.');
        }
        if (payload.consent !== true) {
          throw new Error('É necessário concordar com o armazenamento da imagem.');
        }
        if (!pathname.startsWith('uploads/')) {
          throw new Error('Caminho de upload inválido.');
        }
        return {
          allowedContentTypes: TOKEN_CONTENT_TYPES,
          maximumSizeInBytes: MAX_UPLOAD_BYTES,
          addRandomSuffix: true,
          tokenPayload: JSON.stringify({ consent: true }),
        };
      },
      onUploadCompleted: async () => {
        // Processamento acontece na rota /api/images, após confirmação do cliente.
      },
    });
    return NextResponse.json(json);
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Falha ao autorizar o envio.';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
