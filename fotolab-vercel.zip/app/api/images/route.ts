import { NextResponse } from 'next/server';
import { get, put, del } from '@vercel/blob';
import { randomUUID } from 'node:crypto';
import { analyzeImage } from '@/lib/analyze';
import { ensureSchema, insertImage } from '@/lib/db';
import { MAX_UPLOAD_BYTES, detectFormat, mimeFor } from '@/lib/validate';

export const runtime = 'nodejs';
export const maxDuration = 60;

function safeName(name: string): string {
  const cleaned = name.replace(/[^\w.\- ]+/g, '_').trim().slice(0, 120);
  return cleaned || 'foto';
}

async function discard(url: string) {
  try {
    await del(url);
  } catch {
    // Falha ao remover o arquivo rejeitado não deve mascarar o erro principal.
  }
}

// Recebe a confirmação do envio, valida o conteúdo real do arquivo,
// extrai os metadados, gera miniatura e registra no banco.
export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Requisição inválida.' }, { status: 400 });
  }

  const pathname = typeof body.pathname === 'string' ? body.pathname : '';
  const blobUrl = typeof body.url === 'string' ? body.url : '';
  const originalName = safeName(typeof body.originalName === 'string' ? body.originalName : 'foto');

  if (body.consent !== true) {
    return NextResponse.json({ error: 'Consentimento obrigatório.' }, { status: 400 });
  }
  if (!pathname.startsWith('uploads/') || !blobUrl) {
    return NextResponse.json({ error: 'Envio não encontrado.' }, { status: 400 });
  }

  const stored = await get(pathname, { access: 'private' });
  if (!stored || !stored.stream) {
    return NextResponse.json({ error: 'Envio não encontrado.' }, { status: 404 });
  }

  const buffer = Buffer.from(await new Response(stored.stream).arrayBuffer());

  if (buffer.length === 0 || buffer.length > MAX_UPLOAD_BYTES) {
    await discard(blobUrl);
    return NextResponse.json({ error: 'Tamanho de arquivo inválido.' }, { status: 413 });
  }

  const format = detectFormat(buffer);
  if (!format) {
    await discard(blobUrl);
    return NextResponse.json(
      { error: 'O conteúdo do arquivo não corresponde a JPG, PNG, WebP ou HEIC.' },
      { status: 415 },
    );
  }

  const analysis = await analyzeImage(buffer);
  const id = randomUUID();

  let thumb: { url: string; pathname: string } | null = null;
  if (analysis.thumbnail) {
    thumb = await put(`thumbs/${id}.jpg`, analysis.thumbnail, {
      access: 'private',
      contentType: 'image/jpeg',
      addRandomSuffix: false,
    });
  }

  await ensureSchema();
  const record = await insertImage({
    id,
    originalName,
    mimeType: mimeFor(format),
    format,
    sizeBytes: buffer.length,
    width: analysis.width,
    height: analysis.height,
    capturedAt: analysis.capturedAt,
    cameraMake: analysis.cameraMake,
    cameraModel: analysis.cameraModel,
    latitude: analysis.latitude,
    longitude: analysis.longitude,
    blobUrl,
    blobPathname: pathname,
    thumbUrl: thumb?.url ?? null,
    thumbPathname: thumb?.pathname ?? null,
    metadata: analysis.metadata,
  });

  return NextResponse.json({ image: record, warnings: analysis.warnings });
}
