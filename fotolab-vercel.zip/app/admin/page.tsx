import type { Metadata } from 'next';
import AdminGallery from '@/components/AdminGallery';

export const metadata: Metadata = {
  title: 'Painel — FotoLab',
  robots: { index: false, follow: false },
};

export default function AdminPage() {
  return <AdminGallery />;
}
