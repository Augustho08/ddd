import type { Metadata } from 'next';
import AdminPanel from '@/components/AdminPanel';

export const metadata: Metadata = {
  title: 'Painel · FotoLab',
  robots: { index: false, follow: false },
};

// A página não exibe dados. Os arquivos e registros só são entregues pela API, após a autenticação.
export default function AdminPage() {
  return <AdminPanel />;
}
