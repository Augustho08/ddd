export const metadata = { title: 'Privacidade — FotoLab' };

export default function PrivacidadePage() {
  return (
    <article className="mx-auto max-w-2xl space-y-6 leading-relaxed text-slate-300">
      <h1 className="text-3xl font-bold tracking-tight text-white">Privacidade</h1>
      <p>
        Ao enviar uma fotografia, você concorda que ela seja <strong className="text-white">armazenada</strong> pelo
        FotoLab, com o arquivo original e os metadados extraídos (como data, modelo do aparelho e, quando existir,
        coordenadas GPS).
      </p>
      <p>
        Essas informações podem ser acessadas pelo <strong className="text-white">administrador autorizado</strong> do
        site, que pode visualizar, baixar e excluir os arquivos. Nenhuma imagem é publicada em página aberta ao público.
      </p>
      <h2 className="pt-2 text-xl font-semibold text-white">Coordenadas GPS</h2>
      <p>
        As coordenadas são gravadas pelo próprio aparelho no momento da captura, quando a localização está ativa. Muitos
        aplicativos e redes sociais removem esse dado. Sua presença indica onde a foto foi tirada, não necessariamente
        onde você está agora, e a ausência não garante que a foto não tenha localização.
      </p>
      <h2 className="pt-2 text-xl font-semibold text-white">Exclusão</h2>
      <p>
        O envio pode ser removido pelo administrador a qualquer momento. Remova também do seu aparelho qualquer cópia
        que não deseje manter.
      </p>
      <p className="text-sm text-slate-500">
        Este texto é um modelo técnico. Antes de operar o serviço com o público, revise-o com um profissional jurídico
        e adeque-o à legislação aplicável, como a LGPD.
      </p>
    </article>
  );
}
