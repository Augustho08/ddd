import type { Metadata } from 'next';
import Link from 'next/link';
import './globals.css';

export const metadata: Metadata = {
  title: 'FotoLab · Análise de metadados de fotos',
  description: 'Envie uma foto e veja formato, resolução, data de captura, dispositivo e coordenadas GPS.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>
        <header className="site-header">
          <div className="container">
            <Link href="/" className="brand">
              Foto<span>Lab</span>
            </Link>
          </div>
        </header>
        <main className="container">{children}</main>
        <footer className="site-footer">
          As fotos enviadas são armazenadas de forma privada e acessíveis somente ao administrador.
        </footer>
      </body>
    </html>
  );
}
