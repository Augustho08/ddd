import type { Metadata } from 'next';
import Link from 'next/link';
import { Manrope, JetBrains_Mono } from 'next/font/google';
import './globals.css';

const sans = Manrope({ subsets: ['latin'], variable: '--font-sans', display: 'swap' });
const mono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono', display: 'swap' });

export const metadata: Metadata = {
  title: 'FotoLab — Análise de metadados de fotos',
  description: 'Envie uma foto e veja resolução, data de captura, dispositivo e metadados EXIF, IPTC e XMP.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${sans.variable} ${mono.variable}`}>
      <body className="min-h-screen font-sans">
        <header className="sticky top-0 z-30 border-b border-line/60 bg-ink/75 backdrop-blur-md">
          <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
            <Link href="/" className="text-lg font-semibold tracking-tight text-white">
              Foto<span className="text-accent">Lab</span>
            </Link>
            <Link href="/privacidade" className="text-sm text-slate-400 transition hover:text-white">
              Privacidade
            </Link>
          </nav>
        </header>
        <main className="mx-auto max-w-6xl px-4 py-12 sm:py-16">{children}</main>
        <footer className="mx-auto max-w-6xl px-4 pb-10 text-xs text-slate-500">
          FotoLab · As imagens enviadas são armazenadas de forma privada. Veja a{' '}
          <Link href="/privacidade" className="underline-offset-4 hover:underline">política de privacidade</Link>.
        </footer>
      </body>
    </html>
  );
}
