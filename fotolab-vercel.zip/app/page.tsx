import UploadForm from '@/components/UploadForm';

export default function HomePage() {
  return (
    <div className="grid gap-14 lg:grid-cols-[1.1fr_1fr] lg:items-center">
      <section className="space-y-8">
        <p className="rise inline-flex items-center gap-2 rounded-full border border-line px-3 py-1 font-mono text-xs text-slate-400">
          <span className="h-1.5 w-1.5 rounded-full bg-accent" /> Metadados sob controle
        </p>
        <h1 className="rise rise-delay-1 text-4xl font-bold leading-tight tracking-tight text-white sm:text-5xl">
          Descubra o que a sua foto revela sobre quando e como foi feita.
        </h1>
        <p className="rise rise-delay-2 max-w-xl text-lg leading-relaxed text-slate-400">
          Envie uma imagem e veja resolução, formato, data de captura, modelo do aparelho e os metadados
          embutidos no arquivo. Se a foto tiver localização GPS, ela aparece separada, com a explicação de onde vem.
        </p>
        <ul className="rise rise-delay-2 grid max-w-xl grid-cols-2 gap-4 text-sm text-slate-400">
          <li className="panel p-4">Formatos: JPG, PNG, WebP e HEIC</li>
          <li className="panel p-4">EXIF, IPTC e XMP lidos do próprio arquivo</li>
        </ul>
      </section>

      <section aria-label="Enviar fotografia" className="viewfinder panel p-6 sm:p-8">
        <UploadForm />
      </section>
    </div>
  );
}
