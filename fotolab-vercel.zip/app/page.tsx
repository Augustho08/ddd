import Uploader from '@/components/Uploader';

export default function HomePage() {
  return (
    <div className="home">
      <section className="hero-rise">
        <p className="eyebrow">Análise de metadados</p>
        <h1>Veja o que a sua foto revela.</h1>
        <p className="lead">
          Envie uma imagem para conferir o formato, a resolução, a data de captura, o dispositivo e as coordenadas GPS,
          quando o arquivo as contiver.
        </p>
        <ul className="features">
          <li>JPG, PNG, WebP e HEIC</li>
          <li>EXIF, IPTC e XMP</li>
          <li>Até 25 MB</li>
        </ul>
      </section>

      <section className="card" aria-label="Enviar foto">
        <Uploader />
      </section>
    </div>
  );
}
