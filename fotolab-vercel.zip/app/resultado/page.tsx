'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import type { PhotoRecord } from '@/lib/types';
import { RESULT_STORAGE_KEY } from '@/lib/types';
import { formatBytes, formatDate, formatResolution } from '@/lib/format';

const GROUP_NAMES: Record<string, string> = {
  ifd0: 'Dados da imagem',
  exif: 'EXIF (captura)',
  gps: 'GPS',
  xmp: 'XMP',
  iptc: 'IPTC',
};

function Value({ value }: { value: unknown }) {
  if (value === null || value === undefined) return <>—</>;
  if (typeof value === 'object') return <>{JSON.stringify(value)}</>;
  return <>{String(value)}</>;
}

export default function ResultPage() {
  const [photo, setPhoto] = useState<PhotoRecord | null | undefined>(undefined);

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(RESULT_STORAGE_KEY);
      setPhoto(raw ? (JSON.parse(raw) as PhotoRecord) : null);
    } catch {
      setPhoto(null);
    }
  }, []);

  if (photo === undefined) return <p className="muted">Carregando análise…</p>;

  if (!photo) {
    return (
      <section className="card narrow" style={{ textAlign: 'center' }}>
        <h1 style={{ fontSize: '1.6rem' }}>Nenhuma análise recente</h1>
        <p className="muted" style={{ margin: '10px 0 22px' }}>Envie uma foto para ver os detalhes do arquivo.</p>
        <Link href="/" className="btn btn-primary">Enviar uma foto</Link>
      </section>
    );
  }

  const hasGps = photo.latitude !== null && photo.longitude !== null;
  const device = [photo.cameraMake, photo.cameraModel].filter(Boolean).join(' ') || 'Não informado';
  const groups = Object.entries(photo.metadata);

  return (
    <div>
      <p className="eyebrow">Resultado da análise</p>
      <h1>{photo.originalName}</h1>
      <p className="muted">Enviada em {formatDate(photo.uploadedAt)}</p>

      <section className="section stats" aria-label="Resumo">
        <div className="stat"><span>Formato</span><strong>{photo.format.toUpperCase()}</strong></div>
        <div className="stat"><span>Resolução</span><strong>{formatResolution(photo.width, photo.height)}</strong></div>
        <div className="stat"><span>Tamanho</span><strong>{formatBytes(photo.sizeBytes)}</strong></div>
        <div className="stat"><span>Data de captura</span><strong>{formatDate(photo.capturedAt)}</strong></div>
        <div className="stat"><span>Dispositivo</span><strong>{device}</strong></div>
        <div className="stat"><span>Coordenadas GPS</span><strong>{hasGps ? 'Presentes' : 'Ausentes'}</strong></div>
      </section>

      <section className="section" aria-label="Localização">
        <h2>Localização GPS</h2>
        <div className="gps-box">
          {hasGps ? (
            <>
              <p className="gps-value">
                {photo.latitude!.toFixed(6)}, {photo.longitude!.toFixed(6)}
              </p>
              <div>
                <a
                  className="btn btn-ghost btn-small"
                  href={`https://www.openstreetmap.org/?mlat=${photo.latitude}&mlon=${photo.longitude}#map=15/${photo.latitude}/${photo.longitude}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Ver no mapa
                </a>
              </div>
            </>
          ) : (
            <p>Nenhuma coordenada GPS foi encontrada nos metadados desta foto.</p>
          )}
          <p className="muted">
            As coordenadas são gravadas pelo próprio aparelho na captura, quando a localização está ativa. Redes sociais
            e aplicativos costumam removê-las. Elas indicam onde a foto foi tirada, e não necessariamente onde você está
            agora. A ausência delas não prova que a foto não tenha local.
          </p>
        </div>
      </section>

      <section className="section" aria-label="Metadados">
        <h2>Metadados embutidos</h2>
        {groups.length === 0 && <p className="muted">Este arquivo não contém metadados EXIF, IPTC ou XMP legíveis.</p>}
        {groups.map(([name, data]) => (
          <details key={name} className="group">
            <summary>{GROUP_NAMES[name] ?? name.toUpperCase()}</summary>
            <dl className="kv">
              {Object.entries((data ?? {}) as Record<string, unknown>).map(([key, value]) => (
                <div key={key}>
                  <dt>{key}</dt>
                  <dd><Value value={value} /></dd>
                </div>
              ))}
            </dl>
          </details>
        ))}
      </section>

      <section className="section">
        <Link href="/" className="btn btn-primary" style={{ maxWidth: 320 }}>Analisar outra foto</Link>
      </section>
    </div>
  );
}
