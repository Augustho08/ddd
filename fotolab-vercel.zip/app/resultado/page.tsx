'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import type { ImageRecord } from '@/lib/types';
import { formatBytes, formatDate, formatResolution } from '@/lib/format';

const GROUP_LABELS: Record<string, string> = {
  ifd0: 'Dados principais (IFD0)',
  exif: 'EXIF (captura)',
  gps: 'GPS',
  xmp: 'XMP',
  iptc: 'IPTC',
};

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="panel p-5">
      <p className="text-xs uppercase tracking-wider text-slate-500">{label}</p>
      <p className="mt-2 break-words text-lg font-semibold text-white">{value}</p>
    </div>
  );
}

function MetadataGroup({ name, data }: { name: string; data: unknown }) {
  const entries = Object.entries((data ?? {}) as Record<string, unknown>);
  return (
    <details className="panel group p-5">
      <summary className="flex cursor-pointer list-none items-center justify-between font-medium text-white">
        {GROUP_LABELS[name] ?? name.toUpperCase()}
        <span className="text-slate-500 transition group-open:rotate-45">+</span>
      </summary>
      <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
        {entries.map(([key, value]) => (
          <div key={key} className="min-w-0 border-t border-line/70 pt-3">
            <dt className="font-mono text-xs text-slate-500">{key}</dt>
            <dd className="mt-1 break-words text-slate-200">
              {typeof value === 'object' ? JSON.stringify(value) : String(value)}
            </dd>
          </div>
        ))}
      </dl>
    </details>
  );
}

export default function ResultPage() {
  const [image, setImage] = useState<ImageRecord | null | undefined>(undefined);

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem('fotolab:last-result');
      setImage(raw ? (JSON.parse(raw) as ImageRecord) : null);
    } catch {
      setImage(null);
    }
  }, []);

  if (image === undefined) {
    return <p className="text-slate-500">Carregando análise…</p>;
  }

  if (!image) {
    return (
      <section className="panel mx-auto max-w-lg space-y-4 p-8 text-center">
        <h1 className="text-2xl font-semibold text-white">Nenhuma análise recente</h1>
        <p className="text-slate-400">Envie uma foto para ver os detalhes do arquivo.</p>
        <Link href="/" className="btn-primary">Enviar uma foto</Link>
      </section>
    );
  }

  const hasGps = image.latitude !== null && image.longitude !== null;
  const metadataGroups = Object.entries(image.metadata ?? {});

  return (
    <div className="space-y-10">
      <header className="rise space-y-3">
        <p className="font-mono text-xs text-accent">Resultado da análise</p>
        <h1 className="break-words text-3xl font-bold tracking-tight text-white sm:text-4xl">{image.originalName}</h1>
        <p className="text-slate-400">Enviada em {formatDate(image.uploadedAt)}</p>
      </header>

      <section className="rise rise-delay-1 grid grid-cols-2 gap-4 lg:grid-cols-3">
        <Stat label="Resolução" value={formatResolution(image.width, image.height)} />
        <Stat label="Tamanho" value={formatBytes(image.sizeBytes)} />
        <Stat label="Formato" value={image.format.toUpperCase()} />
        <Stat label="Data de captura" value={formatDate(image.capturedAt)} />
        <Stat
          label="Dispositivo"
          value={[image.cameraMake, image.cameraModel].filter(Boolean).join(' ') || 'Não informado'}
        />
        <Stat label="Tipo MIME" value={image.mimeType} />
      </section>

      <section className="rise rise-delay-2 panel space-y-4 p-6">
        <h2 className="text-xl font-semibold text-white">Localização GPS</h2>
        {hasGps ? (
          <>
            <p className="font-mono text-lg text-accent">
              {image.latitude!.toFixed(6)}, {image.longitude!.toFixed(6)}
            </p>
            <a
              href={`https://www.openstreetmap.org/?mlat=${image.latitude}&mlon=${image.longitude}#map=15/${image.latitude}/${image.longitude}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-ghost"
            >
              Ver no mapa
            </a>
          </>
        ) : (
          <p className="text-slate-400">Nenhuma coordenada GPS foi encontrada nos metadados desta imagem.</p>
        )}
        <p className="text-sm leading-relaxed text-slate-500">
          As coordenadas são gravadas pelo aparelho no momento da captura, quando a localização está ativa. Redes
          sociais e aplicativos costumam remover esse dado. Indica onde a foto foi tirada, não necessariamente onde você
          está agora, e a ausência não prova que a foto não tenha local.
        </p>
      </section>

      <section className="rise rise-delay-2 space-y-4">
        <h2 className="text-xl font-semibold text-white">Metadados embutidos</h2>
        {metadataGroups.length === 0 ? (
          <p className="text-slate-400">Este arquivo não contém metadados EXIF, IPTC ou XMP legíveis.</p>
        ) : (
          metadataGroups.map(([name, data]) => <MetadataGroup key={name} name={name} data={data} />)
        )}
      </section>

      <div className="flex flex-wrap gap-3">
        <Link href="/" className="btn-primary">Analisar outra foto</Link>
      </div>
    </div>
  );
}
