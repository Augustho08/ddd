import { describe, expect, it } from 'vitest';
import { detectFormat, validateFileMeta, MAX_UPLOAD_BYTES, extensionOf } from '../lib/validate';

const bytes = (...values: number[]) => new Uint8Array(values);
const ascii = (s: string) => Array.from(s).map((c) => c.charCodeAt(0));

describe('detectFormat', () => {
  it('reconhece JPEG pela assinatura FF D8 FF', () => {
    expect(detectFormat(bytes(0xff, 0xd8, 0xff, 0xe0, 0, 0, 0, 0, 0, 0, 0, 0))).toBe('jpeg');
  });

  it('reconhece PNG pela assinatura 89 50 4E 47', () => {
    expect(detectFormat(bytes(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0))).toBe('png');
  });

  it('reconhece WebP pelo cabeçalho RIFF....WEBP', () => {
    expect(detectFormat(bytes(...ascii('RIFF'), 0, 0, 0, 0, ...ascii('WEBP')))).toBe('webp');
  });

  it('reconhece HEIC pela marca ftyp heic', () => {
    expect(detectFormat(bytes(0, 0, 0, 0x18, ...ascii('ftypheic')))).toBe('heic');
  });

  it('rejeita AVIF e conteúdo desconhecido', () => {
    expect(detectFormat(bytes(0, 0, 0, 0x18, ...ascii('ftypavif')))).toBeNull();
    expect(detectFormat(bytes(...ascii('<html><body>')))).toBeNull();
  });

  it('rejeita conteúdo menor que o cabeçalho mínimo', () => {
    expect(detectFormat(bytes(0xff, 0xd8))).toBeNull();
  });
});

describe('validateFileMeta', () => {
  it('aceita extensões permitidas em qualquer caixa', () => {
    expect(validateFileMeta('FERIAS.JPG', 1000)).toBeNull();
    expect(validateFileMeta('selfie.heic', 1000)).toBeNull();
  });

  it('rejeita extensões fora da lista', () => {
    expect(validateFileMeta('script.svg', 1000)).not.toBeNull();
    expect(validateFileMeta('arquivo.exe', 1000)).not.toBeNull();
  });

  it('rejeita arquivos vazios e acima de 25 MB', () => {
    expect(validateFileMeta('a.png', 0)).not.toBeNull();
    expect(validateFileMeta('a.png', MAX_UPLOAD_BYTES + 1)).not.toBeNull();
    expect(validateFileMeta('a.png', MAX_UPLOAD_BYTES)).toBeNull();
  });
});

describe('extensionOf', () => {
  it('retorna a extensão em minúsculas', () => {
    expect(extensionOf('Foto.Final.JPEG')).toBe('jpeg');
    expect(extensionOf('sem-extensao')).toBe('');
  });
});
